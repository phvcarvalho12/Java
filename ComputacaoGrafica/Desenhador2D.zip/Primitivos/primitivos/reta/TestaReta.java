package primitivos.reta;

/**
 * Write a description of class TestaReta here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestaReta
{
    public static void main(String args[]) {
        Reta r = new Reta(10, 10, 20, 30);
        System.out.println("Reta: " + r);
    }
}