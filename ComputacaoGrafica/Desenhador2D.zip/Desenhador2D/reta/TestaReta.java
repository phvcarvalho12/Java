package reta;

/**
 * Testa a classe Reta.
 * 
 * @author Julio Arakaki 
 * @version 20220815
 */
public class TestaReta {
    public static void main(String args[]) {
        Reta r = new Reta(10, 10, 20, 30);
        System.out.println("Reta: " + r);
    }
}